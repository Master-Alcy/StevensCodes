#load "ast.cmo";;
#load "ds.cmo";;
#load "lexer.cmo";;
#load "parser.cmo";;
#load "main.cmo";;

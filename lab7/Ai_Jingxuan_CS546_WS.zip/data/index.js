const postData = require("./post");

module.exports = {
    posts: postData
};

//This is operations with database
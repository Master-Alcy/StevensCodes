"use strict";
const usersData = require("./users");

module.exports = {
    users: usersData
};
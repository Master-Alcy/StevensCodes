# How to install and run

npm install

gulp build

npm start

## Some Notes

Need gulp-cli globally installed and for windows 10, open a console with administration right and added it to path variable

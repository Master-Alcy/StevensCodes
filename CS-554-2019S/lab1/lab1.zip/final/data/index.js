//This is operations with database
const taskData = require("./taskData");

module.exports = {
    tasks: taskData
};
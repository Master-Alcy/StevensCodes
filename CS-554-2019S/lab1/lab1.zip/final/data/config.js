//This is information of database
module.exports = {
    serverUrl: "mongodb://localhost:27017/",
    database: "Ai-Jingxuan-CS554-Lab1"
}
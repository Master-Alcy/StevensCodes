# Proceedure

1. npm install
2. npm run seed
3. npm start